<?php
include('connexion.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $filiere = $_POST['filiere'];
    $etudiant = $_POST['etudiant'];
    $matiere = $_POST['matiere'];
    $note_cc = $_POST['note_cc'];
    $note_ce = $_POST['note_ce'];

    
    $moyenne = ($note_cc + $note_ce) / 2;


    $checkFiliere = $conn->prepare("SELECT id_filiere FROM filieres WHERE nom_filiere = ?");
    $checkFiliere->execute([$filiere]);
    $filiereData = $checkFiliere->fetch(PDO::FETCH_ASSOC);

    if ($filiereData) {
        $id_filiere = $filiereData['id_filiere'];
    } else {
        $insertFiliere = $conn->prepare("INSERT INTO filieres (nom_filiere) VALUES (?)");
        $insertFiliere->execute([$filiere]);
        $id_filiere = $conn->lastInsertId();
    }

    
    $checkMatiere = $conn->prepare("SELECT id_matiere FROM matieres WHERE nom_matiere = ?");
    $checkMatiere->execute([$matiere]);
    $matiereData = $checkMatiere->fetch(PDO::FETCH_ASSOC);

    if ($matiereData) {
        $id_matiere = $matiereData['id_matiere'];
    } else {
        $insertMatiere = $conn->prepare("INSERT INTO matieres (nom_matiere, id_filiere) VALUES (?, ?)");
        $insertMatiere->execute([$matiere, $id_filiere]);
        $id_matiere = $conn->lastInsertId();
    }

    $checkEtudiant = $conn->prepare("SELECT id_etudiant FROM etudiants WHERE nom_etudiant = ?");
    $checkEtudiant->execute([$etudiant]);
    $etudiantData = $checkEtudiant->fetch(PDO::FETCH_ASSOC);

    if ($etudiantData) {
        $id_etudiant = $etudiantData['id_etudiant'];
    } else {
        $insertEtudiant = $conn->prepare("INSERT INTO etudiants (nom_etudiant, id_filiere) VALUES (?, ?)");
        $insertEtudiant->execute([$etudiant, $id_filiere]);
        $id_etudiant = $conn->lastInsertId();
    }

    $sql = "INSERT INTO notes (id_etudiant, id_matiere, note_cc, note_ce, moyenne) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id_etudiant, $id_matiere, $note_cc, $note_ce, $moyenne]);

    echo "<p style='color:green;text-align:center;'>✅ Note ajoutée avec succès ! Moyenne = $moyenne / 20</p>";
}
?>

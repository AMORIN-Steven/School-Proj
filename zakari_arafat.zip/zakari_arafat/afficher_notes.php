<?php
include('connexion.php');
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Liste des notes</title>
  <link rel="stylesheet" href="style.css">
  <style>
    table {
      width: 90%;
      margin: 30px auto;
      border-collapse: collapse;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 10px;
      text-align: center;
    }
    th {
      background-color: #007bff;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    h2 {
      text-align: center;
      margin-top: 20px;
    }
    .filter {
      text-align: center;
      margin: 20px;
    }
    .filter form {
      display: inline-block;
    }
    .filter select, .filter button {
      padding: 8px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
  </style>
</head>
<body>
    <nav class="navbar">
  <ul>
    <li><a href="index.html">🏠 Accueil</a></li>
    <li><a href="ajout_note.html">➕ Ajout de note</a></li>
    <li><a href="modification_note.html">✏️ Modification</a></li>
    <li><a href="afficher_notes.php" class="active">📋 Affichage</a></li>
  </ul>
</nav>


  <h2>📋 Liste des Notes Enregistrées</h2>

  <div class="filter">
    <form method="get" action="">
      <label for="filiere">Filtrer par filière :</label>
      <select name="filiere" id="filiere">
        <option value="">-- Toutes les filières --</option>
        <?php
        $sqlFiliere = $conn->query("SELECT * FROM filieres");
        while ($row = $sqlFiliere->fetch(PDO::FETCH_ASSOC)) {
          $selected = (isset($_GET['filiere']) && $_GET['filiere'] == $row['id_filiere']) ? 'selected' : '';
          echo "<option value='{$row['id_filiere']}' $selected>{$row['nom_filiere']}</option>";
        }
        ?>
      </select>
      <button type="submit">Filtrer</button>
    </form>
  </div>

  <table>
    <tr>
      <th>Étudiant</th>
      <th>Filière</th>
      <th>Matière</th>
      <th>Note CC</th>
      <th>Note CE</th>
      <th>Moyenne</th>
      <th>Date</th>
    </tr>

    <?php

    $query = "
      SELECT e.nom_etudiant, f.nom_filiere, m.nom_matiere, n.note_cc, n.note_ce, n.moyenne, n.date_ajout
      FROM notes n
      JOIN etudiants e ON n.id_etudiant = e.id_etudiant
      JOIN matieres m ON n.id_matiere = m.id_matiere
      JOIN filieres f ON e.id_filiere = f.id_filiere
    ";

    if (isset($_GET['filiere']) && $_GET['filiere'] != '') {
      $query .= " WHERE f.id_filiere = " . intval($_GET['filiere']);
    }

    $stmt = $conn->query($query);
    if ($stmt->rowCount() > 0) {
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
                <td>{$row['nom_etudiant']}</td>
                <td>{$row['nom_filiere']}</td>
                <td>{$row['nom_matiere']}</td>
                <td>{$row['note_cc']}</td>
                <td>{$row['note_ce']}</td>
                <td><strong>{$row['moyenne']}</strong></td>
                <td>{$row['date_ajout']}</td>
              </tr>";
      }
    } else {
      echo "<tr><td colspan='7'>Aucune note enregistrée.</td></tr>";
    }
    ?>
  </table>

</body>
</html>

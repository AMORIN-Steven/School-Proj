<?php
include('connexion.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $etudiant = $_POST['etudiant'];
    $matiere = $_POST['matiere'];
    $note_cc = $_POST['note_cc'];
    $note_ce = $_POST['note_ce'];
    $moyenne = ($note_cc + $note_ce) / 2;

    $req = $conn->prepare("
        SELECT n.id_note 
        FROM notes n
        JOIN etudiants e ON n.id_etudiant = e.id_etudiant
        JOIN matieres m ON n.id_matiere = m.id_matiere
        WHERE e.nom_etudiant = ? AND m.nom_matiere = ?
    ");
    $req->execute([$etudiant, $matiere]);
    $noteData = $req->fetch(PDO::FETCH_ASSOC);

    if ($noteData) {
        $id_note = $noteData['id_note'];
        $update = $conn->prepare("
            UPDATE notes 
            SET note_cc = ?, note_ce = ?, moyenne = ?
            WHERE id_note = ?
        ");
        $update->execute([$note_cc, $note_ce, $moyenne, $id_note]);
        echo "<p style='color:green;text-align:center;'>✅ Note mise à jour avec succès ! Nouvelle moyenne = $moyenne / 20</p>";
    } else {
        echo "<p style='color:red;text-align:center;'>⚠️ Étudiant ou matière introuvable dans la base de données.</p>";
    }
}
?>
